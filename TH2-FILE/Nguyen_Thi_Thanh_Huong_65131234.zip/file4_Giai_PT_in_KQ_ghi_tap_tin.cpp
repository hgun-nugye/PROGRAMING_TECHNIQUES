#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int GiaiPTb2(float a, float b, float c, float &x1, float &x2) 
{
	float delta;
	if (a == 0) 
	{
    if (b == 0) 
		{
      if (c == 0) return 10;//vo so nghiem
   		else return 0;//vo nghiem
  	}
		else 
		{
      x1=1.0*-c/b;
      return 1;//duy nhat nghiem
  	}
  }
	else 
	{
   	delta=b*b-4*a*c;
    if (delta>0) 
		{
      x1=(-b + sqrt(delta))/(2*a);
      x2=(-b - sqrt(delta))/(2*a);
      return 2;//2 nghiem phan biet
    }
		else if (delta == 0) 
		{
      x1=-b/(2*a);
      return 11;//nghiem kep
    }
		else return 0;//vo nghiem
  }
}

int main() 
{
  float a, b, c;
	float x1, x2;
  FILE *fi;
  FILE *fo;
	//check input file
  fi = fopen("D:\\C_C++\\PROGRAMING_TECHNIQUES\\TH2-FILE\\ptbac2.txt", "r");
  if (fi == NULL) 
	{
    fprintf(stderr, "Khong the mo file\n");
    return 1;
  }
	//check output file
  fo = fopen("D:\\C_C++\\PROGRAMING_TECHNIQUES\\TH2-FILE\\giai_ptbac2_float.txt", "w");
  if (fo == NULL) 
	{
    fprintf(stderr, "Khong the mo file\n");
    fclose(fi);
    return 1;
  }
	
	//read a, b, c and solve
  while (fscanf(fi, "%f %f %f", &a, &b, &c) != EOF) 
	{
  int result=GiaiPTb2(a, b, c, x1, x2);
  if (result==1) 
	{
		fprintf(fo, "Phuong trinh co duy nhat nghiem x=%.2f\n", x1);
		printf("%.2f x^2 + %.2f x + %.2f = 0\t Duy nhat nghiem x = %.2f\n",a,b,c, x1);
	}
  else
  	if (result==10) 
		{
			fprintf(fo, "Phuong trinh co vo so nghiem\n");
			printf( "%.2f x^2 + %.2f x + %.2f = 0\t Vo so nghiem\n",a,b,c);
		}
  else
		if(result==2) 
		{
			fprintf(fo, "%Phuong trinh co hai nghiem phan biet x1=%.2f; x2=%.2f\n", x1, x2);
			printf("%.2f x^2 + %.2f x + %.2f = 0\t x1 = %.2f; x2 = %.2f\n",a,b,c, x1, x2);
		}
  else 
		if(result==11) 
		{
			fprintf(fo, "Phuong trinh co nghiem kep x1=x2=%.2f\n",x1);
			printf( "%.2f x^2 + %.2f x + %.2f = 0\t Nghiem kep x1 = x2 = %.2f\n",a,b,c,x1);
		}
  else
		if(result==0) 
		{
			fprintf(fo, "Phuong trinh vo nghiem\n");
			printf("%.2f x^2 + %.2f x + %.2f = 0\t Vo nghiem\n");
		}
  }
  fclose(fi);
  fclose(fo);
  return 0;
}